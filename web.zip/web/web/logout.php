<?php
require_once 'config.php';
require_once 'auth.php';

// Perform logout
TelegramAuth::logout();
?>
