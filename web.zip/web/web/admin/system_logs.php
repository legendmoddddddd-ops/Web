<?php // View System Logs: Access raw system and error logs. ?>
